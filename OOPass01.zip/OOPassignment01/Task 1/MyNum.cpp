#include"MyNum.h"

MyNum:: MyNum(int n)      // Here is my Constructor
{
	cout << "Parameterized constructor" << endl;
	number = n;
}
void MyNum::setNum(int n)  //Settter to set num 
{
	number = n;
}
int MyNum::getNum()
{
	return number;
}
int MyNum::ToNegative(int num) //getter to get num
{
	int temp;
	if (num > 0)
	{
		temp = num*(-1);
	}
	else
	{
		temp = num;
	}
	return temp;
}
int MyNum::ToPositive(int num)
{
	int temp;
	if (num < 0)
	{
		temp = num*(-1);
	}
	else
	{
		temp = num;
	}
	return temp;
}
MyNum::~MyNum()       // Here is my Destructor
{
	cout << "~MyNum() - Destructor" << endl;
}

