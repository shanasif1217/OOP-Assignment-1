#include<iostream>
using namespace std;
class MyNum
{
	int number;
public:
	MyNum(int num = 0);
	void setNum(int);
	int getNum();
	int ToNegative(int);
	int ToPositive(int);	
	~MyNum();
};