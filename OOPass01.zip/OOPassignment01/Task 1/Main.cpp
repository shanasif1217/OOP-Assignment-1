#include"MyNum.h"

int main()
{

	MyNum n1(35);
	cout << "Value is";
	cout << n1.getNum() << endl << endl;

	int value = 0;
	cout << "Enter an integer " << endl;
	cin >> value;
	n1.setNum(value);
	cout << "Number is: " << n1.getNum() << endl;
	if (value > 0)
	{
		cout << " Positive integer" << endl;
		n1.ToNegative(value);
		cout << "After convertion: " << n1.getNum() << endl;
	}
	if (value < 0)
	{
		cout << "Negative integer" << endl;
		n1.ToPositive(value);
		cout << "After convertion: " << n1.getNum() << endl;
	}

	int o, sort, val = 0;
	cout << "Enter number of objects: ";
	cin >> o;
	while (o < 0)
	{
		cout << "Please enter positive number: ";
		cin >> o;
	}
	MyNum* ptr = new MyNum[o];
	// Dynamically created array //
	int *arr = new int[o];
	// Input values of objects.
	cout << endl;
	for (int i = 0; i < o; i++)
	{
		cout << "Enter the value of " << i + 1 << " object: ";
		cin >> val;
		ptr[i].setNum(val);
		arr[i] = val;
	}
	cout << endl;
	// Display of these objects.
	for (int i = 0; i < o; i++)
	{
		cout << "Value of object "<< i+1 << " is: " << ptr[i].getNum() << endl;
		if (arr[i] < 0)
		{
			cout << "After convertion: " << ptr[i].ToPositive(arr[i]) << endl;
		}
		else
		{
			cout << "After convertion: " << ptr[i].ToNegative(arr[i]) << endl;
		}
	}
	for (int i = 0; i < o; i++) //sorting
	{
		for (int j = i + 1; j < n; j++)
		{
			if (arr[i]>arr[j])
			{
				sort = arr[i];
				arr[i] = arr[j];
				arr[j] = sort;
			}
		}
		ptr[i].setNum(arr[i]);
	}
	cout << "After sorting:" << endl;  //display of sorted array
	for (int i = 0; i < o; i++)
	{
		cout << "Value of object " << i + 1 << " : " << ptr[i].getNum() << endl;
	}
	cout << endl;
	delete[]ptr; //Deallocation of memory
	ptr = 0;

	delete[]arr;
	arr = 0;

	return 0;
}