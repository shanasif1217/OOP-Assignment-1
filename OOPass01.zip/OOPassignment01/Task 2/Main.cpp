#include"MyChar.h"

int main()
{
	MyChar c1('T');
	cout << "Initialized the value with a character: " << c1.getVariable() << endl;
	char v;
	cout << "\nEnter an alphabet: ";
	cin >> v;
	while (!((v >= 'A' && v <= 'Z') || (v >= 'a' && v <= 'z')))
	{
		cout << "Must be an alphabet. Re-enter the input: ";
		cin >> v;
	}
	c1.setVariable(v);
	//cout<<c1.getVariable() << endl;
	cout << "Upper Case: " << c1.ToUpperCase(v) << endl;
	cout << "Lower Case: " << c1.ToLowerCase(v) << endl;

	// Dynamically created objects //
	int n, temp = 0;
	cout << "-----------------------------------------------------------------" << endl;
	cout << "\nNow, Enter the number of objects you want to create here: ";
	cin >> n;
	MyChar* ptr = new MyChar[n];
	// Dynamically created array //
	char* arr = new char[n];
	cout << endl;
	for (int i = 0; i < n; i++)
	{
		cout << "Enter an alphabet for object " << i + 1 << ": ";
		cin >> arr[i];
		ptr[i].setVariable(arr[i]);
	}
	cout << "-----------------------------------------------------------------" << endl;
	cout << endl;
	for (int i = 0; i < n; i++)
	{
		cout << "Object " << i + 1 << ": " << ptr[i].getVariable() << endl;
		cout << "It's Upper Case: " << ptr[i].ToUpperCase(ptr[i].getVariable()) << endl;
		cout << "Is's Lower Case: " << ptr[i].ToLowerCase(ptr[i].getVariable()) << endl;
	}
	cout << endl;
	// Sorting of dynamically created objects //
	for (int i = 0; i < n;  i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			if (arr[i]>arr[j])
			{
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
		ptr[i].setVariable(arr[i]);
	}

	cout << "\t********************* After SORTING ***********************" << endl;
	for (int i = 0; i < n; i++)
	{
		cout << "Object " << i + 1 << " : " << ptr[i].getVariable() << endl;
	}
	cout << endl;
	// deAllocation of dynamic memory //
	delete[]ptr;
	ptr = nullptr;

	delete[]arr;
	arr = nullptr;

	return 0;
}