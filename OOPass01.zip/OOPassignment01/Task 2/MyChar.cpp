#include"MyChar.h"

MyChar::MyChar(char n)
{
	cout << "Parameterized constructor" << endl;
	if (n == '\0')
	{
		variable = '\0';
	}
	else
	{
		variable = n;
	}
}
void MyChar::setVariable(char n)
{
	variable = n;
}
char MyChar::getVariable()
{
	return variable;
}
char MyChar::ToUpperCase(char n)
{
	if (n >= 97 && n <= 122)
	{	
		n = n - 32;
	}
	return n;
}
char MyChar::ToLowerCase(char n)
{
	if (n >= 65 && n <= 90)
	{
		n= n + 32;
	}
	return n;
}
MyChar::~MyChar()
{
	cout << "~MyChar() - Destructor" << endl;
}