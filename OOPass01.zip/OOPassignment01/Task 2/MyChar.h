#include<iostream>
using namespace std;
class MyChar
{
	char variable;
public:
	MyChar(char n = '\0');
	void setVariable(char);
	char getVariable();
	char ToUpperCase(char);
	char ToLowerCase(char);
   ~MyChar();
};