#include"Name.h"

Name::Name(char* first, char* last)
{
	cout << "Parameterized constructor" << endl;
	// For first Name //
	int len = 0;
	while (first[len] != '\0')
	{
		len++;
	}
	firstName = new char[len + 1];
	for (int i = 0; i < len; i++)
	{
		firstName[i] = first[i];
	}
	firstName[len] = '\0';

	// For second Name //
	len = 0;
	while (last[len] != '\0')
	{
		len++;
	}
	lastName = new char[len + 1];
	for (int i = 0; i < len; i++)
	{
		lastName[i] = last[i];
	}
	lastName[len] = '\0';
}
void Name::setFirstName(char* F)
{
	int len = 0;
	while (F[len] != '\0')
	{
		len++;
	}
	firstName = new char[len + 1];
	for (int i = 0; i < len; i++)
	{
		firstName[i] = F[i];
	}
	firstName[len] = '\0';
}
void Name::setLastName(char* L)
{
	int len = 0;
	while (L[len] != '\0')
	{
		len++;
	}
	lastName = new char[len + 1];
	for (int i = 0; i < len; i++)
	{
		lastName[i] = L[i];
	}
	lastName[len] = '\0';
}
char* Name::getFirstName()
{
	int len = 0;
	char* temp = nullptr;
	while (firstName[len] != '\0')
	{
		len++;
	}
	temp = new char[len + 1];
	for (int i = 0; i < len; i++)
	{
		temp[i] = firstName[i];
	}
	temp[len] = '\0';
	return temp;
}
char* Name::getLastName()
{
	int len = 0;
	char* temp = nullptr;
	while (lastName[len] != '\0')
	{
		len++;
	}
	temp = new char[len + 1];
	for (int i = 0; i < len; i++)
	{
		temp[i] = lastName[i];
	}
	temp[len] = '\0';
	return temp;
}
Name::~Name()   /////////////// Destructor ////////////////
{
	cout << "~Name() - Destructor" << endl;
	delete[]firstName;
	firstName = nullptr;

	delete[]lastName;
	lastName = nullptr;
}
Name::Name(const Name& obj)
{
	cout << "Copy constructor" << endl;
	// copy the first name //
	int count = 0;
	while (obj.firstName[count] != '\0')
	{
		count++;
	}
	firstName = new char[count + 1];
	for (int i = 0; i < count; i++)
	{
		firstName[i] = obj.firstName[i];
	}
	firstName[count] = '\0';

	// Copy the last name //
	count = 0;
	while (obj.lastName[count] != '\0')
	{
		count++;
	}
	lastName = new char[count + 1];
	for (int i = 0; i < count; i++)
	{
		lastName[i] = obj.lastName[i];
	}
	lastName[count] = '\0';
}

void Name::copyName(Name& otherObj)   //////////////////////////////////////////////
{
	int length = 0;
	for (int i = 0; firstName[i] != '\0'; i++)
	{
		length++;
	}
	for (int j = 0; lastName[j] != '\0'; j++)
	{
		length++;
	}
	char*arr = new char[length + 2];
	int i = 0;
	// Copy the full name //
	for (; i < otherObj.firstName[i] != '\0'; i++)
	{
		arr[i] = otherObj.firstName[i];
	}
	arr[i] = ' ';
	i++;
	int k = 0;
	for (; otherObj.lastName[k] != '\0'; k++)
	{
		arr[i] = lastName[k];
		i++;
	}
	arr[i] = '\0';

	cout << "===============> After copy the full name <===============" << endl;
	cout << "Full name: " << arr << endl << endl;
}

void Name::camelCase()
{
	cout << "============> The camel case is <==============" << endl;
	if (firstName[0] >= 97 && firstName[0] <= 122)
	{
		firstName[0] = firstName[0] - 32;
	}
	if (lastName[0] >= 97 && lastName[0] <= 122)
	{
		lastName[0] = lastName[0] - 32;
	}
}
void Name::toLower()//convert name to lower case alphabets
{
	cout << "============> After converting the names into 'Lower case' of alphabtes <==========" << endl;
	for (int i = 0; firstName[i] != '\0'; i++)
	{
		if (firstName[i] >= 65 && firstName[i] <= 90)
		{
			firstName[i] = firstName[i] + 32;
		}
	}
	for (int i = 0; lastName[i] != '\0'; i++)
	{
		if (lastName[i] >= 65 && lastName[i] <= 90)
		{
			lastName[i] = lastName[i] + 32;
		}
	}
}
void Name::toUpper() //convert name into upper case alphabets
{
	cout << "============> After converting the names into 'Upper case' of alphabtes <==========" << endl;
	for (int i = 0; firstName[i] != '\0'; i++)
	{
		if (firstName[i] >= 97 && firstName[i] <= 122)
		{
			firstName[i] = firstName[i] - 32;
		}
	}
	for (int j = 0; lastName[j] != '\0'; j++)
	{
		if (lastName[j] >= 97 && lastName[j] <= 122)
		{
			lastName[j] = lastName[j] - 32;
		}
	}
}
int Name::nameLength() // both first and last (excluding space)
{
	int length = 0;
	int i = 0;
	while (firstName[i] != '\0')
	{
		length++;
		i++;
	}
	i = 0;
	while (lastName[i] != '\0')
	{
		length++;
		i++;
	}
	return length;
}
void Name::swapNames() // firstName becomes lastName and vice versa  
{
	int firstLength = 0, scndLength = 0;
	while (lastName[scndLength] != '\0')
	{
		scndLength++;
	}
	char*one = new char[scndLength + 1];
	while (firstName[firstLength] != '\0')
	{
		firstLength++;
	}
	char*two = new char[firstLength + 1];
	for (int i = 0; i < scndLength; i++)
	{
		one[i] = lastName[i];
	}
	one[scndLength] = '\0';
	for (int i = 0; i < firstLength; i++)
	{
		two[i] = firstName[i];
	}
	two[firstLength] = '\0';
	firstName = new char[scndLength + 1];
	for (int i = 0; i < scndLength; i++)
	{
		firstName[i] = one[i];
	}
	firstName[scndLength] = '\0';
	lastName = new char[firstLength + 1];
	for (int i = 0; i < firstLength; i++)
	{
		lastName[i] = two[i];
	}
	lastName[firstLength] = '\0';
}
void Name::display()  //prints name(firstName and lastName with space in between)
{
	cout << "First name is: " << firstName << endl;
	cout << "Last name is : " << lastName << endl << endl;
	//cout << "Full name is: " << firstName << " " << lastName << endl;
}
char* Name::fullName() //concatenate both attributes and return full name with a space in between both
{
	int length = 0;
	for (int i = 0; firstName[i] != '\0'; i++)
	{
		length++;
	}
	for (int j = 0; lastName[j] != '\0'; j++)
	{
		length++;
	}
	char*arr = new char[length + 2];
	int i = 0;
	for (; i < firstName[i] != '\0'; i++)
	{
		arr[i] = firstName[i];
	}
	arr[i] = ' ';
	i++;
	int k = 0;
	for (; lastName[k] != '\0'; k++)
	{
		arr[i] = lastName[k];
		i++;
	}
	arr[i] = '\0';
	return arr;
}
bool Name::isValidName() // name should contain only alphabets - no special characters or digits //////////////////
{
	bool flag = 0;
	int length = 0, length1 = 0, k = 0;
	for (int i = 0; firstName[i] != '\0'; i++)
	{
		length++;
	}
	for (int j = 0; lastName[j] != '\0'; j++)
	{
		length1++;
	}
	char*temp = new char[length + length1 + 1];
	for (int i = 0; i < length; i++)
	{
		temp[k++] = firstName[i];
	}
	for (int i = 0; lastName[i] != '\0'; i++)
	{
		temp[k++] = lastName[i];
	}
	for (int i = 0; i< length + length1; i++)
	{

		if ((temp[i] >= 'A' && temp[i] <= 'Z') || (temp[i] >= 'a' && temp[i] <= 'z'))
		{
			flag = 0;
		}
		else
		{
			flag = 1;
		}
	}

	if (flag == 0)
	{
		cout << "*********** Names contain only alphabets ***********" << endl;
	}
	else
	{
		cout << "********** Names does not contain only alphabets **********" << endl;
	}
	cout << endl;
	return flag;
}