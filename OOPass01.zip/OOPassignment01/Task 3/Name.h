#include<iostream>
using namespace std;
class Name
{
	char* firstName;
	char* lastName;
public:
	Name(char* first = nullptr, char* last = nullptr);
	void setFirstName(char*);
	void setLastName(char*);
	char* getFirstName();
	char* getLastName();
	Name(const Name&); //copy constructor
	~Name();
	void copyName(Name&); // not a copy constructor	
	void camelCase();
	void toLower();
	void toUpper();
	int nameLength();
	void swapNames();
	void display();
	char* fullName();
	bool isValidName();
};