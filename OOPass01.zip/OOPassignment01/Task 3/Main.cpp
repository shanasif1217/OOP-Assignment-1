#include"Name.h"

int nameCompare(Name name1, Name name2)
{
	char*tempF1 = name1.getFirstName();
	char*tempL1 = name1.getLastName();
	char*tempF2 = name2.getFirstName();
	char*tempL2 = name2.getLastName();
	// For 1st object //
	int length = 0;
	for (int i = 0; tempF1[i] != '\0'; i++)
	{
		length++;
	}
	for (int j = 0; tempL1[j] != '\0'; j++)
	{
		length++;
	}
	char*arr = new char[length + 2];
	int i = 0;
	for (; i < tempF1[i] != '\0'; i++)
	{
		arr[i] = tempF1[i];
	}
	arr[i] = ' ';
	i++;
	int k = 0;
	for (; tempL1[k] != '\0'; k++)
	{
		arr[i] = tempL1[k];
		i++;
	}
	arr[i] = '\0';

	// For second object //
	length = 0;
	for (int i = 0; tempF2[i] != '\0'; i++)
	{
		length++;
	}
	for (int j = 0; tempL2[j] != '\0'; j++)
	{
		length++;
	}
	char*brr = new char[length + 2];
	i = 0;
	for (; i < tempF2[i] != '\0'; i++)
	{
		brr[i] = tempF2[i];
	}
	brr[i] = ' ';
	i++;
	k = 0;
	for (; tempL2[k] != '\0'; k++)
	{
		brr[i] = tempL2[k];
		i++;
	}
	brr[i] = '\0';

	cout << endl;
	cout << "Object 1: " << arr << endl;
	cout << "Object 2: " << brr << endl;

	// compare lexicographically //
	int count = 0, count1 = 0, count2 = 0, index = 0;
	for (int i = 0; arr[i] != '\0'; i++)
	{
		count1++;
	}
	for (int i = 0; brr[i] != '\0'; i++)
	{
		count2++;
	}

	for (int i = 0; arr[i] != '\0'; i++)
	{
		if (arr[i] == brr[i])
		{
			count++;
		}
	}

	if (count == count1)
	{
		cout << "==============> Both names are same <===============" << endl << endl;
		return 0;
	}

	for (int i = 0; arr[i] == brr[i]; i++)
	{
		index = i;
	}
	if (arr[i] > brr[i])
	{
		cout << "========>First name has alphabets with greater ASCII code <===========" << endl << endl;
		return 1;
	}
	else if (arr[i] < brr[i])
	{
		cout << "========>First name has alphabets with smaller ASCII code <===========" << endl << endl;
		return -1;
	}
	delete[]arr;
	arr = nullptr;
	delete[]brr;
	brr = nullptr;
}

int main()  /////// Driver function
{
	Name n1("hassan", "gilani");
	Name n3("ahmad", "gilani");
	//n1.display();
	cout << "First name is: " << n1.getFirstName() << endl;
	cout << "Last name is: " << n1.getLastName() << endl << endl;

	// user enter values //
	char arr[10], brr[10];
	cout << "------------------- Input data of 1st object ------------------" << endl;
	cout << "Enter your first name: ";
	cin >> arr;
	n1.setFirstName(arr);
	cout << "Enter your last name: ";
	cin >> brr;
	n1.setLastName(brr);
	cout << "First name is: " << n1.getFirstName() << endl;
	cout << "Last name is: " << n1.getLastName() << endl << endl;

	cout << "------------------- Input data of 2nd object ------------------" << endl;
	cout << "Enter your first name: ";
	cin >> arr;
	n3.setFirstName(arr);
	cout << "Enter your last name: ";
	cin >> brr;
	n3.setLastName(brr);
	cout << "First name is: " << n3.getFirstName() << endl;
	cout << "Last name is: " << n3.getLastName() << endl << endl;

	// Copy constructor //
	Name n2 = n1;
	n2.display();

	// Compare names lexicography //
	int var;
	cout << "===================> Now, we have to compare the names of two objects <=====================\n";
	cout << "******************** Process of comparing name lexicographically starts from here ******************" << endl;
	var = nameCompare(n1, n3);
	cout << "******************** Process of comparing the names ends here **************************************\n\n\n";

	// copy the name into another name 
	n1.copyName(n1);
	// camel case of names 
	n1.camelCase();
	n1.display();
	// convert to upper case
	n1.toLower();
	n1.display();
	// convert to lower case
	n1.toUpper();
	n1.display();

	// Length of first and last name
	cout << "==============> Length of combined words <===============" << endl;
	cout << "Length of first and last name is: " << n1.nameLength() << endl << endl;

	// your entered full name
	char*full = n1.fullName();
	cout << "=============> Your full name is: " << full << endl;

	// check validity
	bool flag = 0;
	flag = n1.isValidName();

	// Swap first and last name
	cout << "========> After swaping the both names <=========" << endl;
	n1.swapNames();
	cout << "First name: " << n1.getFirstName() << endl;
	cout << "Last name: " << n1.getLastName() << endl << endl;

	return 0;
}